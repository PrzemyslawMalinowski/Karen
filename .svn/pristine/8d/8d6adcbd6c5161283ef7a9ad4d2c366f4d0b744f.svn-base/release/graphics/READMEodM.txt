﻿Kodowanie to: UTF-8
--------------------------------------------------------------------------------
"Oh my gosh. Hold on to your hooves – I am just about to be brilliant!"
												- Pinkie Pie
--------------------------------------------------------------------------------

26.05.2012 - okolice godziny 22 i 23
Okej, teraz kiedy wreszcie poradzilam sobie z OKROPNYM klientem SVN dla Windowsa
bede dosyc czesto zmieniac graficznki - znaczy to duzo committow. HURA! 
Dzisiaj:
	- update mapy (nabiera powoli ksztaltu ostatecznego!)
	- update lvl (usuniecie hardsub'a i gejowego pytajnika), nowy folder LVL
	  niedlugo dodam tam narysowe wszystkie znaki artytmetyczne
	- zmiana sage'a tak by byl uniwersalny
	
27.05.2012
	- dodalam znaki arytmetyczne, jak na razie sa takie, 
	  moze beda inne

31.05.2012 - okolice godziny 22 i 23 (jak zwykle)
	- mapa sie zmienila, ale w szczegolach ktorych pewno nie zauwazycie
	- dodalam mgle wojny do mapy
	- nadal nie mam pomyslow na tokeny dla lasow i gor :<
	- ciekawe czy ktos to czyta
	
13.06.2012 - okolice 18 i 19 (cos nowego)
	- po drodze bylo kilka malych nic, nie znaczacyh updatow, np. z mapy 0.png pozbyla sie flag
	- dodalam male wersje znakow arytmetycznych, fajnie wygladaja w tlumaczeniach
	- dodaje kolejne "prymitywy": banana, gwiazdke, kredka, cukierek, pape Roska